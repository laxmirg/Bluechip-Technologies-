<?php
include("../dbconnect/dbconn.php");
$expenditure_name=$_POST["expenditure_name"];
$description=$_POST["description"];
$total_amount=$_POST["total_amount"];
$given_to=$_POST["given_to"];
$voucher_no=$_POST["voucher_no"];
$given_date=$_POST["given_date"];

$expenditure_id=$_POST["expenditure_id"];

$sql="update expenditure set expenditure_name='$expenditure_name',description='$description',total_amount='$total_amount',given_to='$given_to',given_date='$given_date' where expenditure_id='$expenditure_id'";

mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values updated....");
document.location="expenditures_view.php";
</script>