<!DOCTYPE html>
<html lang="en">
  <head>
<?php include('meta_tag.php');?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
<?php include('header.php');?>
    <!-- Sidebar menu-->
<?php include('sidebar.php');?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>employee_salary</h1>
          <p>Details</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><a href="home.php"?><i class="fa fa-home fa-lg"></i> </a></li>
          
        </ul>
      </div>
	<a href="employee_salary_form.php" class="btn btn-primary">Add New Details</a><hr/>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
    <th>sl_no</th>
    <th>employee_name</th>
    <th>basic_sal</th>
    <th>working_days</th>
    <th>worked_days</span></th>
    <th>ot_days</th>
    <th>other_charges</th>
    <th>pf</th>
    <th>month</th>
    <th>year</th>
    <th>salary_date</th>
    <th width="50">Delete</th>
    <th width="51">Edit</th>
  </tr>
  </thead>
  <tbody>
  <?php
  include("../dbconnect/dbconn.php");
  $sl_no=1;
  $sql="select * from emp_salary es,employee_details ed where es.employee_id=ed.employee_id";
  $res=mysqli_query($conn,$sql); 
  while($row=mysqli_fetch_array($res))
  {
  ?> 
  <tr>
    <td><?php echo $sl_no++;?></td>
    <td><?php echo $row['employee_name'];?></td>
    <td><?php echo $row['basic_sal'];?></td>
    <td><?php echo $row['working_days'];?></td>
    <td><?php echo $row['worked_days'];?></td>
    <td><?php echo $row['ot_days'];?></td>
    <td><?php echo $row['other_charges'];?></td>
    <td><?php echo $row['pf'];?></td>
    <td><?php echo $row['month'];?></td>
    <td><?php echo $row['year'];?></td>
    <td><?php echo $row['salary_date'];?></td>
    <td><a href="employee_salary_delete.php?salary_id=<?php echo $row['salary_id'];?>"class="btn btn-primary">Delete</a></td>
    <td><a href="employee_salary_edit.php?salary_id=<?php echo $row['salary_id'];?>"class="btn btn-danger">edit</a></td>
  </tr>
  <?php 
  }
  ?>
  
</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Essential javascripts for application to work-->
<?php include('script.php');?>
	<?php include('footer.php'); ?>
  </body>
</html>