<?php
include("../dbconnect/dbconn.php");
$vendor_name=$_POST["vendor_name"];
$vendor_address=$_POST["vendor_address"];
$vendor_city=$_POST["vendor_city"];
$contact_no=$_POST["contact_no"];
$email_id=$_POST["email_id"];
$vendor_code=$_POST["vendor_code"];
$gst_no=$_POST["gst_no"];
$vendor_id=$_POST["vendor_id"];


$sql="update vendor_details set vendor_name='$vendor_name',vendor_address='$vendor_address',vendor_city='$vendor_city',contact_no='$contact_no',email_id='$email_id',vendor_code='$vendor_code',gst_no='$gst_no' where vendor_id='$vendor_id'";
mysqli_query($conn,$sql);
?>
<script language="javascript1.2">
alert("values updated....");
document.location="VENDORS_DETAILS_view.php";
</script>