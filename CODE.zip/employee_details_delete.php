<?php
include("../dbconnect/dbconn.php");
$emp_id=$_REQUEST['e_id'];
$sql="delete from employee_details where $emp_id=employee_id";
mysqli_query($conn,$sql);
?>
<script>
 alert("Value deleted");
document.location='employee_details_view.php';
</script>
