<?php
include("../dbconnect/dbconn.php");

$product_name=$_POST["product_name"];
$product_description=$_POST["product_description"];
$product_image=$_POST["product_image"];
$product_price=$_POST["product_price"];

$product_id=$_REQUEST["product_id"];
 $sql="update product_details set product_name='$product_name',product_description='$product_description',product_image='$product_image',product_price='$product_price' where product_id='$product_id'";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
echo alert("values updates....");
//document.location="PRODUCTION_DETAILS_view.php";
</script>