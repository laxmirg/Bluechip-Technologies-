<?php
include("../dbconnect/dbconn.php");
$employee_id=$_POST["employee_id"];
$basic_sal=$_POST["basic_sal"];
$working_days=$_POST["working_days"];
$worked_days=$_POST["worked_days"];
$ot_days=$_POST["ot_days"];
$other_charges=$_POST["other_charges"];
$pf=$_POST["pf"];
$month=$_POST["month"];
$year=$_POST["year"];
$salary_date=$_POST["salary_date"];
$sql="insert into emp_salary values (null,'$employee_id','$basic_sal','$working_days','$worked_days','$ot_days','$other_charges','$pf','$month','$year','$salary_date')";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values inserted....");
document.location="employee_salary_view.php";
</script>