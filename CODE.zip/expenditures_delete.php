<?php
include("../dbconnect/dbconn.php");
$exp_id=$_REQUEST['e_id'];
$sql="delete from expenditure where $exp_id = expenditure_id" ;
mysqli_query($conn,$sql);
?>
<script>
alert("Value deleted");
document.location='expenditures_view.php';
</script>