<?php
include("../dbconnect/dbconn.php");
$product_id=$_POST["product_id"];
$stock=$_POST["stock"];


$sql="insert into stock_details values (null,'$product_id','$stock')";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values inserted....");
document.location="STOCK_DETAILS_view.php";
</script>