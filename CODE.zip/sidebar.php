    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user"><img class="app-sidebar__user-avatar" src="https://s3.amazonaws.com/uifaces/faces/twitter/jsa/48.jpg" alt="User Image">
        <div>
          <p class="app-sidebar__user-name">Mahalaxmi R Gandalati</p>
          <p class="app-sidebar__user-designation">Blue chip technologies</p>
        </div>
      </div>
      <ul class="app-menu">
        <li><a class="app-menu__item" href="home1.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Home</span></a></li>
		
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Vendor</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="VENDORS_DETAILS_view.PHP"><i class="icon fa fa-circle-o"></i>Vendor Details</a></li>
            <li><a class="treeview-item" href="VENDORS_PAYMENT_view.PHP" rel="noopener"><i class="icon fa fa-circle-o"></i>Vendor Payment Details</a></li>

          </ul>
        </li>
		
		
        <li><a class="app-menu__item" href="expenditures_view.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Expenditures</span></a></li>
		
        <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-edit"></i><span class="app-menu__label">Employee</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="employee_details_view.php"><i class="icon fa fa-circle-o"></i> Employee Details</a></li>
            <li><a class="treeview-item" href="employee_salary_view.php"><i class="icon fa fa-circle-o"></i>Employee Salary</a></li>
           
          </ul>
        </li>
		<li><a class="app-menu__item" href="STOCK_DETAILS_view.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Stock Details</span></a></li>
		
        <li class="treeview "><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Production Details</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item" href="PRODUCTION_DETAILS_view.php"><i class="icon fa fa-circle-o"></i> Production Details</a></li>
            <li><a class="treeview-item active" href="PRODUCTION_view.PHP"><i class="icon fa fa-circle-o"></i>Production</a></li>
			
			
          </ul>
        </li>
				
		
		<li class="treeview "><a class="app-menu__item" href="#" data-toggle="treeview"><i class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Raw material Details</span><i class="treeview-indicator fa fa-angle-right"></i></a>
          <ul class="treeview-menu">
            <li><a class="treeview-item active" href="RAW_MATREAIL_DETAILS_view.PHP"><i class="icon fa fa-circle-o"></i>Raw Material Details</a></li>
			<li><a class="treeview-item active" href="RAW_MATREAIL_PURCHASE_DETAILS_view.php"><i class="icon fa fa-circle-o"></i>Raw Material Purchase Details</a></li>
			<li><a class="treeview-item active" href="RAW_MATREAIL_PURCHASE_view.PHP"><i class="icon fa fa-circle-o"></i>Raw Material Purchase</a></li>
			
			
          </ul>
        </li>
		
		
		
		<li><a class="app-menu__item" href="change pwd.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Change Password</span></a></li>
		<li><a class="app-menu__item" href="../logout.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Logout</span></a></li>

      </ul>
    </aside>