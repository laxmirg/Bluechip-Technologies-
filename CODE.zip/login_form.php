<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Untitled Document</title>
</head>

<body>
<form name="form1" method="post" action="">
  <table width="342" border="1" align="center">
    <tr>
      <td colspan="2"><div align="center">Login Page </div></td>
    </tr>
    <tr>
      <td width="170">Password</td>
      <td width="156"><input name="password" type="password" id="password"></td>
    </tr>
    <tr>
      <td>Type</td>
      <td><input name="type" type="text" id="type"></td>
    </tr>
    <tr>
      <td>Hint Question</td>
      <td><textarea name="hint_q" id="hint_q"></textarea></td>
    </tr>
    <tr>
      <td>Hint Answer </td>
      <td><textarea name="hint_a" id="hint_a"></textarea></td>
    </tr>
    <tr>
      <td>Status</td>
      <td><input name="status" type="text" id="status"></td>
    </tr>
    <tr>
      <td colspan="2"><div align="center">
        <input type="submit" name="Submit" value="Submit">
        <input type="reset" name="Reset" value="Reset">
      </div></td>
    </tr>
  </table>
</form>
</body>
</html>
