<?php
include("../dbconnect/dbconn.php");
$vendor_id=$_POST["vendor_id"];
$amount=$_POST["amount"];
$narration=$_POST["narration"];
$date=$_POST["date"];
$vendor_payment_id=$_POST["vendor_payment_id"];


$sql="update vendor_payment set vendor_id='$vendor_id',amount='$amount',narration='$narration',date='$date' where vendor_payment_id='$vendor_payment_id'";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values updated....");
document.location="VENDORS_PAYMENT_view.PHP";
</script>
