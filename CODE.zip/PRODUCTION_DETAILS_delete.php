<?php
include("../dbconnect/dbconn.php");
$prod_id=$_REQUEST['pr_id'];
$sql="delete from product_details where $prod_id=product_id";
mysqli_query($conn,$sql);
?>
<script>
 alert("Value deleted");
document.location='employee_details_view.php';
</script>
