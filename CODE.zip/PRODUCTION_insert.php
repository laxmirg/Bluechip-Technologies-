<?php
include("../dbconnect/dbconn.php");
$product_id=$_POST["product_id"];
$total_production=$_POST["total_production"];
$description=$_POST["description"];
$production_date=$_POST["production_date"];


$sql="insert into production values (null,'$product_id','$total_production','$description','$production_date')";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values inserted....");
document.location="PRODUCTION_view.PHP";
</script>