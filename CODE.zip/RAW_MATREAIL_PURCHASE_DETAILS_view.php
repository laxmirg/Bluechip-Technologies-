<!DOCTYPE html>
<html lang="en">
  <head>
<?php include('meta_tag.php');?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
<?php include('header.php');?>
    <!-- Sidebar menu-->
<?php include('sidebar.php');?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>RAW_MATREAIL_PURCHASE_DETAILS</h1>
          <p>Details</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><a href="home.php"?><i class="fa fa-home fa-lg"></i> </a></li>
          
        </ul>
      </div>
	<a href="RAW_MATREAIL_PURCHASE_DETAILS_FORM.PHP" class="btn btn-primary">Add New Details</a><hr/>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
    <th>sl_no</th>
    <th>date</th>
    <th>raw_material_name</th>
    <th>rate</th>
    <th>discount</th>
    <th>delete</th>
    <th>edit</th>
  </tr>
  </thead>
  <tbody>
 <?php
  include("../dbconnect/dbconn.php");
  $sl_no=1;
  $sql="select * from raw_material_purchase_details rmpd,raw_material_purchase rmp,raw_material_details rmd where rmpd.raw_material_purchase_id=rmp.raw_material_purchase_id and rmpd.raw_material_id=rmd.raw_material_id";
  $res=mysqli_query($conn,$sql); 
  while($row=mysqli_fetch_array($res))
  {
  ?>  
  <tr>
    <td><?php echo $sl_no++; ?></td>
    <td><?php echo $row['date'];?></td>
    <td><?php echo $row['raw_material_name'];?></td>
    <td><?php echo $row['quantity'];?></td>
    <td><?php echo $row['rate'];?></td>
    <td><?php echo $row['discount'];?></td>
    <td><a href="RAW_MATREAIL_PURCHASE_DETAILS_delete.php?raw_material_purchase_details_id=<?php echo $row['raw_material_purchase_details_id'];?>"class="btn btn-primary">Delete</a></td>
    <td><a href="RAW_MATREAIL_PURCHASE_DETAILS_edit.php?raw_material_purchase_details_id=<?php echo $row['raw_material_purchase_details_id'];?>"class="btn btn-danger">edit</a></td>
  </tr>
  <?php 
  }
  ?> 
</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Essential javascripts for application to work-->
<?php include('script.php');?>
	<?php include('footer.php'); ?>
  </body>
</html>