<!DOCTYPE html>
<html lang="en">
  <head>
<?php include('meta_tag.php');?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
<?php include('header.php');?>
    <!-- Sidebar menu-->
<?php include('sidebar.php');?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>expenditures</h1>
          <p>Details</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><a href="home.php"?><i class="fa fa-home fa-lg"></i> </a></li>
          
        </ul>
      </div>
	<a href="expenditures_form.php" class="btn btn-primary">Add New Details</a><hr/>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                    <tr>
    <th>sl No </th>
    <th>Expenditure Name </th>
    <th>Description</th>
    <th>Total Amount</th>
    <th>Given To</th>
    <th>Voucher Number</th>
    <th>Given Date </th>
    <th>Delete</th>
    <th>Edit</th>
  </tr>
  </thead>
  <tbody>
  <?php
  include("../dbconnect/dbconn.php");
  $sl_no=1;
  $sql="select * from expenditure";
  $res=mysqli_query($conn,$sql); 
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $sl_no++; ?></td>
    <td><?php echo $row['expenditure_name'];?></td>
    <td><?php echo $row['description'];?></td>
    <td><?php echo $row['total_amount'];?></td>
    <td><?php echo $row['given_to'];?></td>
    <td><?php echo $row['voucher_no'];?></td>
    <td><?php echo $row['given_date'];?></td>
    <td><a href="expenditures_delete.php?e_id=<?php echo $row['expenditure_id'];?>"class="btn btn-primary">Delete</a></td>
    <td><a href="expenditures_edit.php?expenditure_id=<?php echo $row['expenditure_id'];?>"class="btn btn-danger">edit</a></td>
  </tr>
  <?php 
  }
  ?>
</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Essential javascripts for application to work-->
<?php include('script.php');?>
	<?php include('footer.php'); ?>
  </body>
</html>
