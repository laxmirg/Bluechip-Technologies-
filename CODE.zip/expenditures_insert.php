<?php
include("../dbconnect/dbconn.php");
$expenditure_name=$_POST["expenditure_name"];
$description=$_POST["description"];
$total_amount=$_POST["total_amount"];
$given_to=$_POST["given_to"];
$voucher_no=$_POST["voucher_no"];
$given_date=$_POST["given_date"];

$sql="insert into expenditure values (null,'$expenditure_name','$description','$total_amount','$given_to','$voucher_no','$given_date')";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values inserted....");
document.location="expenditures_view.php";
</script>