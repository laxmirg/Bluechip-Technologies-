<?php
include("../dbconnect/dbconn.php");
$product_id=$_POST["product_id"];
$stock=$_POST["stock"];
$stock_id=$_POST["stock_id"];

$sql="update stock_details set product_id='$product_id',stock='$stock' where stock_id='$stock_id'";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values updated....");
document.location="STOCK_DETAILS_view.php";
</script>