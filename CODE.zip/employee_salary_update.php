<?php
include("../dbconnect/dbconn.php");
$employee_id=$_POST["employee_id"];
$basic_sal=$_POST["basic_sal"];
$working_days=$_POST["working_days"];
$worked_days=$_POST["worked_days"];
$ot_days=$_POST["ot_days"];
$other_charges=$_POST["other_charges"];
$pf=$_POST["pf"];
$month=$_POST["month"];
$year=$_POST["year"];
$salary_date=$_POST["salary_date"];
$salary_id=$_POST["salary_id"];

$sql="update emp_salary set employee_id='$employee_id',basic_sal='$basic_sal',working_days='$working_days',worked_days='$worked_days',ot_days='$ot_days',other_charges='$other_charges',other_charges='$other_charges',pf='$pf',month='$month',year='$year',salary_date='$salary_date' where salary_id='$salary_id'";

mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
 alert("values updated.....");
document.location="employee_salary_view.php";
</script>