<!DOCTYPE html>
<html lang="en">
  <head>
<?php include('meta_tag.php');?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
<?php include('header.php');?>
    <!-- Sidebar menu-->
<?php include('sidebar.php');?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>employee_details</h1>
          <p>Details</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><a href="home.php"?><i class="fa fa-home fa-lg"></i> </a></li>
          
        </ul>
      </div>
	<a href="employee_details_form.php" class="btn btn-primary">Add New Details</a><hr/>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
    <th>sl_no</th>
    <th>employee_name</th>
    <th>employee_address</th>
    <th>employee_city</th>
    <th>gender</span></th>
    <th>contact_no</span></th>
    <th>employee_type</th>
    <th>employee_designaton</th>
    <thO>basic_salary</th>
    <th width="52">Delete</th>
    <th width="42">Edit</th>
  </tr>
  </thead>
  <tbody>
   <?php
  include("../dbconnect/dbconn.php");
  $sl_no=1;
  $sql="select * from employee_details";
  $res=mysqli_query($conn,$sql); 
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $sl_no++; ?></td>
    <td><?php echo $row['employee_name'];?></td>
    <td><?php echo $row['employee_address'];?></td>
    <td><?php echo $row['employee_city'];?></td>
    <td><?php echo $row['gender'];?></td>
    <td><?php echo $row['contact_no'];?></td>
    <td><?php echo $row['employee_type'];?></td>
    <td><?php echo $row['employee_designaton'];?></td>
    <td><?php echo $row['basic_salary'];?></td>
    <td><a href="employee_details_delete.php?e_id=<?php echo $row['employee_id'];?>"class="btn btn-primary">Delete</a></td>
    <td><a href="employee_details_edit.php?employee_id=<?php echo $row['employee_id'];?>"class="btn btn-danger">edit</a></td>
  </tr>
   <?php 
  }
  ?>
</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Essential javascripts for application to work-->
<?php include('script.php');?>
	<?php include('footer.php'); ?>
  </body>
</html>