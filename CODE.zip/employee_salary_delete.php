<?php
include("../dbconnect/dbconn.php");
$salary_id=$_REQUEST['salary_id'];
$sql="delete from emp_salary where $salary_id=salary_id";
mysqli_query($conn,$sql);
?>
<script>
alert("Value deleted");
document.location='employee_salary_view.php';
</script>