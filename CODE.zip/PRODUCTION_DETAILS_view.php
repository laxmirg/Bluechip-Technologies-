<!DOCTYPE html>
<html lang="en">
  <head>
<?php include('meta_tag.php');?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
<?php include('header.php');?>
    <!-- Sidebar menu-->
<?php include('sidebar.php');?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>PRODUCTION_DETAILS</h1>
          <p>Details</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><a href="home.php"?><i class="fa fa-home fa-lg"></i> </a></li>
          
        </ul>
      </div>
	<a href="PRODUCTION_DETAILS_FORM.PHP" class="btn btn-primary">Add New Details</a><hr/>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
    <th>sl_no</th>
    <th>product_name</th>
    <th>product_description</th>
    <th>product_image</th>
    <th>product_price</th>
    <th>Delete</th>
    <th>Edit</th>
  </tr>
  </thead>
  <tbody>
  <?php
  include("../dbconnect/dbconn.php");
  $sl_no=1;
  $sql="select * from product_details";
  $res=mysqli_query($conn,$sql); 
  while($row=mysqli_fetch_array($res))
  {
  ?> 
 <tr>
    <td><?php echo $sl_no++; ?></td>
    <td><?php echo $row['product_name'];?></td>
    <td><?php echo $row['product_description'];?></td>
    <td>&nbsp;<img src="../images/<?php echo $row['product_image'];?>" width="100" height="200"></td>
    <td><?php echo $row['product_price'];?></td>
    <td><a href="PRODUCTION_DETAILS_delete.php?pr_id=<?php echo $row['product_id'];?>"class="btn btn-primary">Delete</a></td>
    <td><a href="PRODUCTION_DETAILS_edit.php?product_id=<?php echo $row['product_id'];?>"class="btn btn-danger">edit</a></td>
  </tr>
   <?php 
  }
  ?>
</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Essential javascripts for application to work-->
<?php include('script.php');?>
	<?php include('footer.php'); ?>
  </body>
</html>