<!DOCTYPE html>
<html lang="en">
  <head>
<?php include('meta_tag.php');?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
<?php include('header.php');?>
    <!-- Sidebar menu-->
<?php include('sidebar.php');?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-th-list"></i>stock_details</h1>
          <p>Details</p>
        </div>
        <ul class="app-breadcrumb breadcrumb side">
          <li class="breadcrumb-item"><a href="home.php"?><i class="fa fa-home fa-lg"></i> </a></li>
          
        </ul>
      </div>
	<a href="STOCK_DETAILS_FORM.php" class="btn btn-primary">Add New Details</a><hr/>
      <div class="row">
        <div class="col-md-12">
          <div class="tile">
            <div class="tile-body">
              <table class="table table-hover table-bordered" id="sampleTable">
                <thead>
                  <tr>
    <td>sl_no</td>
    <td>product_id</td>
    <td>stock</td>
    <td>Delete</td>
    <td>edit</td>
  </tr>
  </thead>
  <tbody>
  <?php
  include("../dbconnect/dbconn.php");
  $sl_no=1;
  $sql="select * from stock_details";
  $res=mysqli_query($conn,$sql); 
  while($row=mysqli_fetch_array($res))
  {
  ?>
  <tr>
    <td><?php echo $sl_no++; ?></td>
    <td><?php echo $row['product_id'];?></td>
    <td><?php echo $row['stock'];?></td>
    <td><a href="STOCK_DETAILS_delete.php?stock_id=<?php echo $row['stock_id'];?>"class="btn btn-primary">Delete</a></td>
    <td><a href="STOCK_DETAILS_edit.php?stock_id=<?php echo $row['stock_id'];?>"class="btn btn-danger">edit</a></td>
  </tr>
 <?php 
  }
  ?> 
</tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </main>

    <!-- Essential javascripts for application to work-->
<?php include('script.php');?>
	<?php include('footer.php'); ?>
  </body>
</html>