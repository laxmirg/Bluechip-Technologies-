<?php
include("../dbconnect/dbconn.php");
$product_name=$_POST["product_name"];
$product_description=$_POST["product_description"];

$product_image=$_FILES['product_image']['name'];
$tmp_location=$_FILES['product_image']['tmp_name'];
$target="../images/".$product_image;
move_uploaded_file($tmp_location,$target);

$product_price=$_POST["product_price"];

$sql="insert into product_details values (null,'$product_name','$product_description','$product_image','$product_price')";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values inserted....");
document.location="PRODUCTION_DETAILS_view.php";
</script>