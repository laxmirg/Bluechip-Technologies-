<?php
include("../dbconnect/dbconn.php");
$employee_name=$_POST["employee_name"];
$employee_address=$_POST["employee_address"];
$employee_city=$_POST["employee_city"];
$gender=$_POST["gender"];
$contact_no=$_POST["contact_no"];
$employee_type=$_POST["employee_type"];
$employee_designaton=$_POST["employee_designaton"];
$basic_salary=$_POST["basic_salary"];

$employee_id=$_POST["employee_id"];

$sql="update employee_details set employee_name='$employee_name',employee_address='$employee_address',employee_city='$employee_city',gender='$gender',contact_no='$contact_no',employee_type='$employee_type',employee_designaton='$employee_designaton',basic_salary='$basic_salary' where employee_id='$employee_id'";
mysqli_query($conn,$sql);
?>

<script language="javascript1.2">
alert("values updated....");
document.location="employee_details_view.php";
</script>