<?php
include("../dbconnect/dbconn.php");
$stock_id=$_REQUEST['stock_id'];
$sql="delete from stock_details where $stock_id =stock_id ";
mysqli_query($conn,$sql);
?>
<script>
 alert("Value deleted");
document.location='STOCK_DETAILS_view.php';
</script>
