<?php
include('../dbconnect/dbconn.php');
$raw_material_purchase_details_id=$_REQUEST['raw_material_purchase_details_id'];
$sql="delete from raw_material_purchase_details where $raw_material_purchase_details_id=raw_material_purchase_details_id";
mysqli_query($conn,$sql);
?>
<script>
alert("Value deleted");
document.location='RAW_MATREAIL_PURCHASE_DETAILS_view.php';
</script>
