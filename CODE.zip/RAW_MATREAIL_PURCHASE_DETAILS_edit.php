<!DOCTYPE html>
<html lang="en">
  <?php include('meta_tag.php');?>
  </head>
  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
  <?php include('header.php');?>
    <!-- Sidebar menu-->
    <?php include('sidebar.php'); ?>
    <main class="app-content">
      <div class="app-title">
        <div>
          <h1><i class="fa fa-edit"></i>RAW_MATREAIL_PURCHASE_DETAILS</h1>		
          <p>form</p>
        </div>
        <ul class="app-breadcrumb breadcrumb">
          <li class="breadcrumb-item"><A href="home.php"><i class="fa fa-home fa-lg"></i></A></li>
        
        </ul>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="tile">
            <br/>
            <div class="tile-body">
<?php
include('../dbconnect/dbconn.php');
$raw_material_purchase_details_id=$_REQUEST['raw_material_purchase_details_id'];
$sql="select * from raw_material_purchase_details where raw_material_purchase_details_id='$raw_material_purchase_details_id'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($res);
?>

<form name="form1" method="post" id="formID" action="RAW_MATREAIL_PURCHASE_DETAILS_update.PHP">
<input type="hidden" name="raw_material_purchase_details_id" value="<?php echo $row['raw_material_purchase_details_id'];?>">
  <div align="center">
    <p><strong>RAW MATERAIL PURCHASE DETAIL </strong></p>
    <table width="389" border="1">
      <tr>
        <td width="40">raw_material_date</span></td>
        <td><select name="raw_material_purchase_id" id="raw_material_purchase_id"  class="validate[Required]">
          <option>select_date</option>
		  <?php
		include("../dbconnect/dbconn.php");
		$sql="select * from raw_material_purchase";
		$res=mysqli_query($conn,$sql);
		while($row=mysqli_fetch_array($res))
		{
		?>
		<option value="<?php echo $row['raw_material_purchase_id'];?>"><?php echo $row['date'];?></option>
		<?php
		}
		?>
        </select></td>
      </tr>
      <tr>
  <td><span style="color: rgb(0, 0, 0); font-family: sans-serif; font-size: 13.12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 700; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: nowrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(253, 253, 254); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">raw_material_name</span></td>
        <td><select name="raw_material_id" id="raw_material_id" class="validate[Required]">
          <option>select_name</option>
		  <?php
		include("../dbconnect/dbconn.php");
		$sql="select * from raw_material_details";
		$res=mysqli_query($conn,$sql);
		while($row=mysqli_fetch_array($res))
		{
		?>
		<option value="<?php echo $row['raw_material_id'];?>"><?php echo $row['raw_material_name'];?></option>
		<?php
		}
		?>
        </select></td>
      </tr>
      <tr>
        <td><span style="color: rgb(0, 0, 0); font-family: sans-serif; font-size: 13.12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 700; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: nowrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(253, 253, 254); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">quantity</span></td>
        <td><input name="quantity" class="form-control validate[required,custom[onlyNumber]]" type="text" id="quantity" value="<?php echo $row['quantity'];?>"></td>
      </tr>
      <tr>
        <td><span style="color: rgb(0, 0, 0); font-family: sans-serif; font-size: 13.12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 700; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: nowrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(253, 253, 254); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">rate</span></td>
        <td><input name="rate" class="form-control validate[required,custom[onlyNumber]]" type="text" id="rate" value="<?php echo $row['rate'];?>"></td>
      </tr>
      <tr>
        <td><span style="color: rgb(0, 0, 0); font-family: sans-serif; font-size: 13.12px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 700; letter-spacing: normal; orphans: 2; text-align: left; text-indent: 0px; text-transform: none; white-space: nowrap; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; background-color: rgb(253, 253, 254); text-decoration-thickness: initial; text-decoration-style: initial; text-decoration-color: initial; display: inline !important; float: none;">discount</span></td>
        <td><input name="discount" class="form-control validate[required,custom[onlyNumber]]" type="text" id="discount" value="<?php echo $row['discount'];?>"></td>
      </tr>
      <tr>
        <td colspan="2">
          <div align="center">
            <input type="submit" class="btn btn-primary" name="Submit" value="Submit">
            <input type="reset" class="btn btn-primary" name="Reset" value="Reset">
          </div></td>
      </tr>
    </table>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
    <p>&nbsp;</p>
  </div>
</form>
</div>

           
          </div>
        </div>
        
       
    </main>
    <!-- Essential javascripts for application to work-->
<?php include('script.php');?>
<?php include('val.php');?>
  </body>
</html>	